Repo for my Final Project, an information website on myself.
Site Focuses on my Hobbies and on my Work/Educational Experiences

Using Jsiarto Boilerplate as most basic template
